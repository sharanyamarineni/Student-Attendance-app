package com.example.sharanya.myapplication;
import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Build;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.TimeZone;

import static android.Manifest.permission.ACCESS_COARSE_LOCATION;
import static android.Manifest.permission.ACCESS_FINE_LOCATION;

public class MainActivity extends AppCompatActivity {

    private ArrayList<String> permissionsToRequest;
    private ArrayList<String> permissionsRejected = new ArrayList<>();
    private ArrayList<String> permissions = new ArrayList<>();
    Attendance mydb;
    private final static int ALL_PERMISSIONS_RESULT = 1;
    LocationTrack locationTrack;
    public String latitude;
    public String longitude;
    /*-----------*/

    private String TAG = MainActivity.class.getSimpleName();

    private ProgressDialog pDialog;
    private ListView lv;

    // URL to get contacts JSON
    private static String url = "https://msitis-iiith.appspot.com/api/profile/ag5ifm1zaXRpcy1paWl0aHIUCxIHU3R1ZGVudBiAgICAgOSRCww";

    ArrayList<HashMap<String, String>> userList;
    String name;
    String email;
    String rollnumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mydb=new Attendance(this);
        userList = new ArrayList<>();

       // lv = (ListView) findViewById(R.id.list);

        new GetUser().execute();
        permissions.add(ACCESS_FINE_LOCATION);
        permissions.add(ACCESS_COARSE_LOCATION);

        permissionsToRequest = findUnAskedPermissions(permissions);
        ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);

        Button btn = (Button) findViewById(R.id.location);


        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                locationTrack = new LocationTrack(MainActivity.this);


                if (locationTrack.canGetLocation()) {

                    longitude = locationTrack.getLongitude()+"";
                    latitude = locationTrack.getLatitude()+"";

                    Toast.makeText(getApplicationContext(), "Longitude:" + longitude + "\nLatitude:" + latitude, Toast.LENGTH_SHORT).show();
                } else {

                    locationTrack.showSettingsAlert();
                }

            }
        });

        Button button = (Button) findViewById(R.id.btn);

/*       Attendance in database            */
        Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("GMT+5:30"));
        Date now = calendar.getTime();
        SimpleDateFormat date = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
        String currentTime = date.format(now);

        final Attendance attendanceContract = new Attendance(getApplicationContext());
        attendanceContract.insert(1, 0.25,"0","0");
        attendanceContract.insert(2, 0.25,"0","0");
        attendanceContract.insert(3, 0.5,"0","0");

        button.setOnClickListener(new View.OnClickListener() {
            Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("GMT+5:30"));
            Date now = calendar.getTime();
            SimpleDateFormat date = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
            String currentTime = date.format(now);
            @Override
            public void onClick(View v) {
                Log.v("ttt",currentTime+"");
                int flag=0;
                if ((currentTime.compareTo("08:50:00")>0 )&& (currentTime.compareTo("09:10:00")<0)){
                    Log.v("ttttt","session1111");

                    attendanceContract.update(1,latitude,longitude);
                    Toast.makeText(getApplicationContext(), "Checked in successfully", Toast.LENGTH_SHORT).show();
                    flag=1;


                }
               else if (currentTime.compareTo("10:40:00")>0 && currentTime.compareTo("11:10:00")<0){
                    Log.v("ttttt","session2222");
                    attendanceContract.update(2,latitude,longitude);
                    Toast.makeText(getApplicationContext(), "Checked in successfully", Toast.LENGTH_SHORT).show();
                    flag=1;


                }
                else if (currentTime.compareTo("13:50:00")>0 && currentTime.compareTo("14:10:00")<0){
                    Log.v("ttttt","session333");
                    attendanceContract.update(3,latitude,longitude);
                    Toast.makeText(getApplicationContext(), "Checked in successfully", Toast.LENGTH_SHORT).show();
                    flag=1;


                }
//                if(flag==1)
//                    Toast.makeText(getApplicationContext(), "Checked in successfully", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(getApplicationContext(), "Check in not available ", Toast.LENGTH_SHORT).show();


            }
        });
    }

    public void viewing(View view)
    {
        Cursor res=mydb.getData();
        if(res.getCount()==0){
            setMessage("Error","Nothing found");
            return;
        }

        StringBuffer buffer=new StringBuffer();
        while(res.moveToNext()){
            // buffer.append("sesssion: "+res.getString(0)+"\n");
            buffer.append("date: "+res.getString(0)+"\n");
           buffer.append("session: "+res.getString(1)+"\n");
           buffer.append("penalty: "+res.getString(2)+"\n");
           buffer.append("latitude: "+res.getString(3)+"\n");
            buffer.append("longitude: "+res.getString(4)+"\n\n");


        }
        setMessage("Data",buffer.toString());
    }
    public void setMessage(String title,String Message){
        android.support.v7.app.AlertDialog.Builder builder=new android.support.v7.app.AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();


    }


    private class GetUser extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // Showing progress dialog
            pDialog = new ProgressDialog(MainActivity.this);
            pDialog.setMessage("Please wait...");
            pDialog.setCancelable(false);
            pDialog.show();

        }

        @Override
        protected Void doInBackground(Void... arg0) {
            HttpHandler sh = new HttpHandler();

            // Making a request to url and getting response
            String jsonStr = sh.makeServiceCall(url);

            Log.e(TAG, "Response from url: " + jsonStr);

            if (jsonStr != null) {
                try {
                    JSONObject jsonObj = new JSONObject(jsonStr);

                    // Getting JSON Array node
                    JSONArray contacts = jsonObj.getJSONArray("data");
                    for (int i = 0; i < contacts.length(); i++) {
                        JSONObject c = contacts.getJSONObject(i);

                        name = c.getString("student_fullname");
                        rollnumber=c.getString("roll_number");
                        email = c.getString("student_email");

                        HashMap<String, String> user = new HashMap<>();

                        user.put("name", name);
                        user.put("email", email);
                        user.put("rollnumber",rollnumber);


                        userList.add(user);
                    }
                } catch (final JSONException e) {
                    Log.e(TAG, "Json parsing error: " + e.getMessage());
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(),
                                    "Json parsing error: " + e.getMessage(),
                                    Toast.LENGTH_LONG)
                                    .show();
                        }
                    });

                }
            } else {
                Log.e(TAG, "Couldn't get json from server.");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getApplicationContext(),
                                "Couldn't get json from server. Check LogCat for possible errors!",
                                Toast.LENGTH_LONG)
                                .show();
                    }
                });

            }

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            if (pDialog.isShowing())
                pDialog.dismiss();

            TextView nam = findViewById(R.id.name);
            nam.setText(name);

            TextView em = findViewById(R.id.email);
            em.setText(email);

            TextView rn = findViewById(R.id.rollnumber);
            rn.setText(rollnumber);
        }

    }

    private ArrayList<String> findUnAskedPermissions(ArrayList<String> wanted) {
        ArrayList<String> result = new ArrayList<String>();

        for (String perm : wanted) {
            if (!hasPermission(perm)) {
                result.add(perm);
            }
        }

        return result;
    }

    private boolean hasPermission(String permission) {
        if (canMakeSmores()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                return (checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED);
            }
        }
        return true;
    }

    private boolean canMakeSmores() {
        return (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP_MR1);
    }



    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {

        switch (requestCode) {

            case ALL_PERMISSIONS_RESULT:
                for (String perms : permissionsToRequest) {
                    if (!hasPermission(perms)) {
                        permissionsRejected.add(perms);
                    }
                }

                if (permissionsRejected.size() > 0) {


                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        if (shouldShowRequestPermissionRationale(permissionsRejected.get(0))) {
                            showMessageOKCancel("These permissions are mandatory for the application. Please allow access.",
                                    new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                                requestPermissions(permissionsRejected.toArray(new String[permissionsRejected.size()]), ALL_PERMISSIONS_RESULT);
                                            }
                                        }
                                    });
                            return;
                        }
                    }

                }

                break;
        }

    }

    private void showMessageOKCancel(String message, DialogInterface.OnClickListener okListener) {
        new AlertDialog.Builder(MainActivity.this)
                .setMessage(message)
                .setPositiveButton("OK", okListener)
                .setNegativeButton("Cancel", null)
                .create()
                .show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        locationTrack.stopListener();
    }
}